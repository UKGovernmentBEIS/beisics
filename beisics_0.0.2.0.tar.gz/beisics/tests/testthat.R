library(testthat)
library(beisics)

test_check("beisics")
